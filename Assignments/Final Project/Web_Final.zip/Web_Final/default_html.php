<?php

class default_html {
	
public static $header = <<< HEAD
	<!doctype html>
	<html>
	<head>
	<title>Final Project</title>
	<meta name="description" content="Ryan's Final Project">
	<meta name="keywords" content="Ryan,Bates,Final,Project">
	<meta name="author" content="Ryan Bates">
	<link rel="stylesheet" type="text/css" href="style.css">
	<link rel="stylesheet" type="text/css" href="print.css" media="print">
	</head>
	<body>
	<div id="header">
	<div id="logo"><h1 class="center">Luminary: Bjarne Stroistrup</h1></div>
	<div id="nav">
	<ul>
	<li><a href="home.php">Bjarne Stroistrup</a></li>
	<li><a href="discussion.php">Luminary Discussion</a></li>
	<li><a href="guestbook.php">Guest Book</a></li>
	<li><a href="webstore.php">Web Store</a></li>
	</ul>
	</div>
	</div>
	</div>
	</body>
HEAD;

public static $footer = <<< FOOT
	<div id="footer">
	Bates copyright 2014 Ryan Bates - 
	<a href="mailto:ryan@notarealsite.com">ryan@notarealsite.com</a>
	</div>
FOOT;

}

?>

