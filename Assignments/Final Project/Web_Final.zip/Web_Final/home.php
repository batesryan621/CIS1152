<?php

require_once "default_html.php";

echo default_html::$header;

$body = <<< BODY
<div id="content">
<img src="bjarne.jpg" alt="Bjarne" style='float:right'>
<h2>Biography - Bjarne Stroistrup</h2>
<p>&nbsp&nbsp&nbsp&nbspBjarne Stroistrup both first name and last underlined in red was born on December 30th of 1950.  This computer scientist invented the language most people know as C++.  He also holds the College of Engineering Chair in Computer Science at Texas A&M University.  Bjarne Stroistrup has a master's degree in mathematics and computer science from Aarthus University, Denmark, and a ph.D in computer science from the University of Cambridge, England.  After all of that, he suffered a painful death by drowning in college debt (Just kidding).<br><br>
&nbsp&nbsp&nbsp&nbspBjarne Stroistrup starting developing C++ in 1978, and also wrote a textbook specially for the language, called "The C++ Programming Language", and others known as "A Tour of C++", "Programming: Principles and Practice Using C++", "The Design and Evolution of C++", and "The Annotated C++ Reference Manual" also developed by Margaret A. Ellis.  Stroistrup was head of the AT&T Bell Labs' Research Department from until late 2002.  He was elected member of the National Academy of Engineering in 2004.  He now works at Texas A&M University as a Distinguished Professor and also as a visiting faculty member at Columbia University.</p> 
</div>
BODY;

echo $body;
echo default_html::$footer;

?>
