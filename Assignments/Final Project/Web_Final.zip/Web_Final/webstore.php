<?php

require_once "default_html.php";

echo default_html::$header;

$body = <<< BODY
<div id="content">
<h2>Stroistrup Web Store</h2>

<table style='width:50%'>
<tr>
<th>Cover</th><th>Purchase Books by Bjarne Stroistrup</th>
<tr><td><img src="book1.jpg"></img></td><td>Click <a href="http://www.amazon.com/Tour-In-Depth-Series-Bjarne-Stroustrup/dp/0321958314">here</a> to purchase "A Tour of C++" from Amazon.</td></tr>
<tr><td><img src="book2.jpg"></img></td><td>Click <a href="http://books.google.com/books/about/Programming.html?id=Ud7LLQAACAAJ">here</a> to purchase "Programming..." from Google Books.</td></tr>
<tr><td><img src="book3.jpg"></img></td><td>Click <a href="http://books.google.com/books/about/The_Design_and_Evolution_of_C++.html?id=gsh3CkM3UBoC">here</a> to purchase "The Design and Evolution of C++" from Google Books.</td></tr>
<tr><td><img src="book4.jpg"></img></td><td>Click <a href="http://www.barnesandnoble.com/w/annotated-c-reference-manual-margaret-a-ellis/1100891578?ean=9780201514599">here</a> to purchase "The Annotated C++ Reference Manual" from Barnes & Noble.</td></tr>
<tr><td><img src="book5.jpg"></img></td><td>Click <a href="http://www.amazon.com/The-Programming-Language-3rd-Edition/dp/0201889544">here</a> to purchase "The C++ Programming Language" from Amazon.</td></tr>
</tr></table>
</div>
BODY;

echo $body;

echo default_html::$footer;

?>