<?php

require_once "default_html.php";

echo default_html::$header;

$body = <<< BODY
<div id="content">
<h3>Welcome, guests! <br><br> Please write me something...</h3><br>
<form name="guestbook" method="post" action="">
<label>Name: </label><input name="name" type="text"><br><br>
<label>Thoughts: <br></label><textarea name="thoughts" rows="4" cols="50"></textarea><br>
<input type="submit" name="submit" value="Submit"><br>
</form>
</div>
BODY;

echo $body;

$DBServer = '127.0.0.1';
$DBUser = 'root';
$DBPass = '';
$DBName = 'finalproject';
$conn = new mysqli($DBServer,$DBUser,$DBPass,$DBName);
if($conn->connect_error){
	die('Error: ' . $conn->connect_errorno);
}

if(isset($_POST['submit'])){
	if ($_POST['name']==''||$_POST['thoughts']=='') {

	} else {
		$name = "'" . $conn->real_escape_string($_POST['name']) . "'";
		$user_thoughts = "'" . $conn->real_escape_string($_POST['thoughts']) . "'";

		$sql = $conn->query("INSERT INTO guestbook(name,thoughts,time_stamp) VALUES($name,$user_thoughts,NOW());");

		if($sql === false){
			die("Error: " . $conn->errno);
		}

		echo "<div id='content'><table style='width:100%'>
		<tr><th style='width:20%'>Name</th>
		<th style='width:60%'>Thoughts</th>
		<th style='width:20%'>Last Posted</th>";

		$result = $conn->query("SELECT name, thoughts, time_stamp FROM guestbook;");
		while ($row = $result->fetch_assoc()) {
			echo "<tr><td>" . $row['name'] . "</td><td>" . $row['thoughts'] . "</td><td>" . $row['time_stamp'] . "</td></tr>";
		}
		echo "</table></div>";

		echo default_html::$footer;
	}
} else {
	echo "<div id='content'><table>
	<tr><th style='width:20%'>Name</th>
	<th style='width:60%'>Thoughts</th>
	<th style='width:20%'>Last Posted</th>";

	$result = $conn->query("SELECT name, thoughts, time_stamp FROM guestbook;");
	while ($row = $result->fetch_assoc()) {
		echo "<tr><td>" . $row['name'] . "</td><td>" . $row['thoughts'] . "</td><td>" . $row['time_stamp'] . "</td></tr>";
	}
	echo "</table></div>";

	echo default_html::$footer;
}

?>