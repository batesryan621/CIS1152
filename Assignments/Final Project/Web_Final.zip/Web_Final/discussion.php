<?php

require_once "default_html.php";

echo default_html::$header;

$body = <<< BODY
<div id="content">
<h2>Discuss Bjarne Stroistrup</h1>
<form name="postdiscussion" method="post" action="">
<label>Name: </label><input name="name" type="text"><br><br>
<label>Discuss: <br></label><textarea name="user_post" rows="4" cols="50"></textarea><br>
<input type="submit" name="submit" value="Submit"><br>
</form>
</div>
BODY;

echo $body;

$DBServer = '127.0.0.1';
$DBUser = 'root';
$DBPass = '';
$DBName = 'finalproject';
$conn = new mysqli($DBServer,$DBUser,$DBPass,$DBName);
if($conn->connect_error){
	die('Error: ' . $conn->connect_errorno);
}

if(isset($_POST['submit'])){
	if ($_POST['name']==''||$_POST['user_post']=='') {

	} else {
		$name = "'" . $conn->real_escape_string($_POST['name']) . "'";
		$user_post = "'" . $conn->real_escape_string($_POST['user_post']) . "'";

		$sql = $conn->query("INSERT INTO posts(FirstName,Post) VALUES($name,$user_post);");

		if($sql === false){
			die("Error: " . $conn->errno);
		}

		$result = $conn->query("SELECT FirstName, Post FROM posts;");

		echo "<div id='content'><table>
		<tr><th style='width:20%'>Name</th>
		<th style='width:80%'>Comment</th>";

		while ($row = $result->fetch_assoc()) {
			echo "<tr><td>" . $row['FirstName'] . "</td><td>" . $row['Post'] . "</td></tr>";
		}
		echo "</table></div>";

		echo default_html::$footer;
	}
} else {
	$result = $conn->query("SELECT FirstName, Post FROM posts;");

	echo "<div id='content'><table>
	<tr><th style='width:20%'>Name</th>
	<th style='width:80%'>Comment</th>";

	while ($row = $result->fetch_assoc()) {
		echo "<tr><td>" . $row['FirstName'] . "</td><td>" . $row['Post'] . "</td></tr>";
	}
	echo "</table></div>";

	echo default_html::$footer;
}

?>